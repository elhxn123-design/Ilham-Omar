ILHAM OMAR - ACADEMIC PORTFOLIO WEBSITE
Open index.html in a web browser. Keep index.html, style.css and script.js together.

The CAT requests a portfolio based on the CV/profile prepared in Week 2. That CV/profile was not supplied with the CAT screenshots, so placeholders remain for the university, degree programme, dates, email, profile link and specific projects. Replace bracketed text with your real details before publishing. The site includes Home, About, Education, Skills, Projects, Research Interests and Contact sections, navigation, styling and a mobile media query for screens up to 600px.
