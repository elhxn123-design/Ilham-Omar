const button=document.querySelector('.menu');const links=document.querySelector('.links');
button.addEventListener('click',()=>{const open=links.classList.toggle('open');button.setAttribute('aria-expanded',String(open));});
document.querySelectorAll('.links a').forEach(a=>a.addEventListener('click',()=>{links.classList.remove('open');button.setAttribute('aria-expanded','false');}));
document.getElementById('year').textContent=new Date().getFullYear();